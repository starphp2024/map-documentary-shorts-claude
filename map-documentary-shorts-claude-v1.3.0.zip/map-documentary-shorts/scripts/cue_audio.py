"""Align a map timeline to individually recorded or synthesized Thai cues."""

from copy import deepcopy
from itertools import pairwise
import math
import subprocess
import wave

SAMPLE_RATE = 48_000
BYTES_PER_SAMPLE = 2


def decode_cue(ffmpeg, path):
    if not path.is_file():
        raise ValueError(f"missing narration cue: {path}")
    command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(path),
               "-map", "0:a:0", "-ac", "1", "-ar", str(SAMPLE_RATE),
               "-f", "s16le", "pipe:1"]
    decoded = subprocess.run(command, capture_output=True, check=False)
    if decoded.returncode or not decoded.stdout:
        detail = decoded.stderr.decode("utf-8", errors="replace").strip()
        raise ValueError(f"cannot decode narration cue {path}: {detail or 'empty audio'}")
    return decoded.stdout


def retime_scene(scene, cues, seconds):
    anchors = [(0, 0)]
    for draft, spoken in zip(scene.get("cues", []), cues):
        anchors.extend([(draft["start"], spoken["start"]), (draft["end"], spoken["end"])])
    anchors.append((scene["seconds"], seconds))

    def adjust(time):
        if time <= 0:
            return 0
        for (start, new_start), (end, new_end) in pairwise(anchors):
            if end > start and time <= end:
                return new_start + (time - start) * (new_end - new_start) / (end - start)
        return seconds

    result = deepcopy(scene)
    result.update(seconds=seconds, cues=cues)
    for group in ("regions", "routes"):
        for overlay in result.get(group, []):
            if "reveal" in overlay:
                overlay["reveal"] = [adjust(time) for time in overlay["reveal"]]
    for marker in result.get("markers", []):
        if "show_from" in marker:
            marker["show_from"] = adjust(marker["show_from"])
    return result


def align_cue_audio(ffmpeg, scenes, draft_frames, directory, wav_path, fps):
    if not any(scene.get("cues") for scene in scenes):
        raise ValueError("--cue-audio requires at least one subtitle cue")
    aligned_scenes = []
    aligned_frames = []
    frame_offset = 0
    with wave.open(str(wav_path), "wb") as narration:
        narration.setparams((1, BYTES_PER_SAMPLE, SAMPLE_RATE, 0, "NONE", "not compressed"))
        for index, (scene, original_frames) in enumerate(zip(scenes, draft_frames), 1):
            start_sample = round(frame_offset * SAMPLE_RATE / fps)
            scene_samples = 0
            previous_end = 0
            cues = []
            for cue_index, cue in enumerate(scene.get("cues", []), 1):
                gap = round((cue["start"] - previous_end) * SAMPLE_RATE)
                narration.writeframesraw(bytes(gap * BYTES_PER_SAMPLE))
                scene_samples += gap
                cue_start = scene_samples / SAMPLE_RATE
                pcm = decode_cue(ffmpeg, directory / f"{index:02d}-{cue_index:02d}.wav")
                narration.writeframesraw(pcm)
                scene_samples += len(pcm) // BYTES_PER_SAMPLE
                cues.append(dict(cue, start=cue_start, end=scene_samples / SAMPLE_RATE))
                previous_end = cue["end"]
            if cues:
                tail_samples = round((scene["seconds"] - previous_end) * SAMPLE_RATE)
                needed_frames = (scene_samples + tail_samples) * fps / SAMPLE_RATE
                count = max(1, math.ceil(needed_frames - 1e-9))
            else:
                count = original_frames
            frame_offset += count
            end_sample = round(frame_offset * SAMPLE_RATE / fps)
            silence_samples = max(0, end_sample - start_sample - scene_samples)
            narration.writeframesraw(bytes(silence_samples * BYTES_PER_SAMPLE))
            aligned_scenes.append(retime_scene(scene, cues, count / fps))
            aligned_frames.append(count)
    return aligned_scenes, aligned_frames
