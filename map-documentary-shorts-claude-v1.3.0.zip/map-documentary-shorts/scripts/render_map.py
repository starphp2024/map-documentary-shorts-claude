#!/usr/bin/env python3
"""Render a vertical map timeline to H.264 MP4 and a Thai SRT sidecar."""

import argparse
from functools import lru_cache
from itertools import pairwise
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

from PIL import Image, ImageColor, ImageDraw, ImageFilter, ImageFont, features

from cue_audio import align_cue_audio

DEFAULT_FONT = Path(__file__).resolve().parents[1] / "assets" / "fonts" / "Kanit-Bold.ttf"


def parse_size(value):
    width, height = map(int, value.lower().split("x"))
    if min(width, height) < 96 or width % 2 or height % 2 or width >= height:
        raise ValueError("--size must use even portrait dimensions, e.g. 1080x1920")
    return width, height


def ramp(time, start, end):
    if start == end:
        return float(time >= start)
    return min(1.0, max(0.0, (time - start) / (end - start)))


def interpolate(first, last, fraction):
    return first + (last - first) * fraction


def camera_transform(camera, time, duration, source_size, output_size, attribution=None):
    start = camera.get("from", (0.5, 0.5, 1.0))
    end = camera.get("to", start)
    progress = min(1.0, time / duration)
    eased = progress * progress * (3.0 - 2.0 * progress)
    x, y, zoom = [interpolate(a, b, eased) for a, b in zip(start, end)]
    source_width, source_height = source_size
    width, height = output_size
    ratio = width / height
    full_width = min(source_width, source_height * ratio)
    view_width = full_width / zoom
    min_left, min_top = 0, 0
    max_left, max_top = source_width, source_height
    if attribution:
        ax0, ay0, ax1, ay1 = [value * dimension for value, dimension in
                              zip(attribution, (source_width, source_height) * 2)]
        view_width = max(view_width, ax1 - ax0, (ay1 - ay0) * ratio)
        if view_width > full_width:
            raise ValueError("credit box cannot fit the camera aspect ratio")
        min_left, min_top = ax1, ay1
        max_left, max_top = ax0, ay0
    view_height = view_width / ratio
    left = min(max(x * source_width - view_width / 2, min_left - view_width, 0),
               max_left, source_width - view_width)
    top = min(max(y * source_height - view_height / 2, min_top - view_height, 0),
              max_top, source_height - view_height)
    crop = (left, top, left + view_width, top + view_height)

    def project(point):
        return ((point[0] * source_width - left) * width / view_width,
                (point[1] * source_height - top) * height / view_height)

    return crop, project


def route_prefix(points, fraction):
    lengths = [math.dist(start, end) for start, end in pairwise(points)]
    remaining = sum(lengths) * fraction
    drawn = [points[0]]
    for (start, end), length in zip(pairwise(points), lengths):
        if length == 0:
            continue
        if remaining < length:
            if remaining > 0:
                x, y = [interpolate(a, b, remaining / length) for a, b in zip(start, end)]
                drawn.append((x, y))
            break
        drawn.append(end)
        remaining -= length
    return drawn


@lru_cache(maxsize=48)
def font_at(path, pixels):
    return ImageFont.truetype(path, pixels, layout_engine=ImageFont.Layout.RAQM)


@lru_cache(maxsize=16)
def open_icon(path, width):
    with Image.open(path) as source:
        icon = source.convert("RGBA")
    height = max(1, round(icon.height * width / icon.width))
    return icon.resize((width, height), Image.Resampling.LANCZOS)


def place_icon(image, icon_path, position, size, angle=0):
    icon = open_icon(icon_path, max(1, round(size)))
    if angle:
        icon = icon.rotate(-math.degrees(angle), resample=Image.Resampling.BICUBIC, expand=True)
    x, y = position
    image.paste(icon, (round(x - icon.width / 2), round(y - icon.height / 2)), icon)


@lru_cache(maxsize=8)
def open_region_mask(path):
    with Image.open(path) as source:
        return source.convert("L")


def draw_region(image, region, project, crop, time, root):
    alpha = round(255 * region.get("opacity", 0.45) * ramp(time, *region.get("reveal", (0, 0))))
    if not alpha:
        return
    color = ImageColor.getrgb(region["color"])
    if "mask" in region:
        mask = open_region_mask(root / region["mask"]).transform(
            image.size, Image.Transform.EXTENT, crop, Image.Resampling.BILINEAR,
        ).point([round(value * alpha / 255) for value in range(256)])
        image.paste(color, (0, 0, *image.size), mask)
    else:
        ImageDraw.Draw(image, "RGBA").polygon(
            [project(point) for point in region["points"]], fill=(*color, alpha),
        )


def draw_route(image, route, project, time, root):
    progress = ramp(time, *route.get("reveal", (0, 0)))
    if progress == 0:
        return
    points = route_prefix([project(point) for point in route["points"]], progress)
    if len(points) < 2:
        return
    draw = ImageDraw.Draw(image)
    color = route.get("color", "#FFFFFF")
    weight = max(2, round(image.width * route.get("width", 0.010)))
    outline = route.get("outline", "#12202A")
    x, y = points[-1]
    previous_x, previous_y = points[-2]
    angle = math.atan2(y - previous_y, x - previous_x)
    arrow = None
    if route.get("arrow", True):
        head = max(8, weight * 3)
        arrow = [
            (x, y),
            (x - head * math.cos(angle - 0.50), y - head * math.sin(angle - 0.50)),
            (x - head * math.cos(angle + 0.50), y - head * math.sin(angle + 0.50)),
        ]
    if route.get("glow"):
        halo = Image.new("L", image.size)
        glow = ImageDraw.Draw(halo)
        glow.line(points, width=weight * 3, fill=200, joint="curve")
        if arrow:
            glow.polygon(arrow, fill=230)
        image.paste(ImageColor.getrgb(route["glow"]), (0, 0, *image.size),
                    halo.filter(ImageFilter.GaussianBlur(weight)))
    draw.line(points, fill=outline, width=weight + max(2, weight // 2), joint="curve")
    draw.line(points, fill=color, width=weight, joint="curve")
    if arrow:
        draw.polygon(arrow, fill=color, outline=outline, width=max(1, weight // 5))
    if route.get("icon"):
        place_icon(image, root / route["icon"], (x, y),
                   image.width * route.get("icon_scale", 0.07), angle)


def draw_text(image, text, position, font_path, size, max_width, boxed=False):
    if not text:
        return
    draw = ImageDraw.Draw(image)
    pixels = max(8, round(size))
    stroke = max(1, round(size / 19))
    options = {"align": "center", "spacing": max(2, round(size * 0.19)), "stroke_width": stroke}
    while True:
        font = font_at(font_path, pixels)
        left, top, right, bottom = draw.multiline_textbbox((0, 0), text, font=font, **options)
        if right - left <= max_width or pixels == 8:
            break
        pixels = max(8, min(pixels - 1, int(pixels * max_width / (right - left))))
    x, y = position
    origin = (round(x - (left + right) / 2), round(y - (top + bottom) / 2))
    if boxed:
        padding = max(4, round(pixels / 4))
        draw.rounded_rectangle(
            (origin[0] + left - padding, origin[1] + top - padding,
             origin[0] + right + padding, origin[1] + bottom + padding),
            radius=padding, fill="#121922",
        )
    draw.multiline_text(origin, text, font=font, fill="white", stroke_fill="#151B22", **options)


def render_frame(base, scene, time, duration, size, font_path, root):
    width, height = size
    attribution = scene.get("attribution_box")
    crop, project = camera_transform(scene.get("camera", {}), time, duration, base.size, size, attribution)
    image = base.transform(size, Image.Transform.EXTENT, crop, resample=Image.Resampling.BICUBIC)
    if attribution:
        left, top = project(attribution[:2])
        right, bottom = project(attribution[2:])
        credit_box = (max(0, math.floor(left)), max(0, math.floor(top)),
                      min(width, math.ceil(right)), min(height, math.ceil(bottom)))
        original_credit = image.crop(credit_box)
    for region in scene.get("regions", []):
        draw_region(image, region, project, crop, time, root)
    for route in scene.get("routes", []):
        draw_route(image, route, project, time, root)
    for marker in scene.get("markers", []):
        x, y = project(marker["at"])
        if time < marker.get("show_from", 0) or not (0 <= x < width and 0 <= y < height):
            continue
        radius = max(3, width * 0.007)
        if marker.get("icon"):
            place_icon(image, root / marker["icon"], (x, y), width * 0.06)
        elif marker.get("pin", True):
            ImageDraw.Draw(image).ellipse((x-radius, y-radius, x+radius, y+radius),
                                          fill="white", outline="#101A26", width=2)
        draw_text(image, marker.get("text", ""), (x, y - width * 0.060),
                  font_path, width * 0.039, width * 0.42)
    draw_text(image, scene.get("context", ""), (width * 0.46, height * 0.16),
              font_path, width * 0.028, width * 0.72, boxed=True)
    draw_text(image, scene.get("annotation", ""), (width * 0.46, height * 0.22),
              font_path, width * 0.023, width * 0.70, boxed=True)
    caption = next((cue["text"] for cue in scene.get("cues", [])
                    if cue["start"] <= time < cue["end"]), "")
    draw_text(image, caption, (width * 0.46, height * 0.70),
              font_path, width * 0.055, width * 0.72)
    draw_text(image, scene.get("credit", ""), (width * 0.46, height * 0.93),
              font_path, width * 0.016, width * 0.76)
    if attribution:
        image.paste(original_credit, credit_box[:2])
    return image


def require_number(value, lower, upper, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lower <= value <= upper:
        raise ValueError(f"{field} must be between {lower} and {upper}")


def validate_points(points, minimum, field):
    if len(points) < minimum or any(len(point) != 2 for point in points):
        raise ValueError(f"{field} needs at least {minimum} [x, y] points")
    for point in points:
        for coordinate in point:
            require_number(coordinate, 0, 1, field)


def validate_scenes(scenes, root, size, fps):
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("the timeline must contain a nonempty scenes list")
    frames = []
    for index, scene in enumerate(scenes, 1):
        try:
            seconds = scene["seconds"]
            require_number(seconds, 1 / fps, math.inf, "seconds")
            if not math.isfinite(seconds):
                raise ValueError("seconds must be finite")
            with Image.open(root / scene["map"]) as image:
                source_size = image.size
                if abs(image.width / image.height - size[0] / size[1]) > 0.003:
                    raise ValueError("map must have the same aspect ratio as the output")
            attribution = scene.get("attribution_box")
            if scene.get("source") == "google-earth" and attribution is None:
                raise ValueError("Google Earth scenes require the original attribution_box")
            if attribution is not None:
                if len(attribution) != 4:
                    raise ValueError("attribution_box must be [left, top, right, bottom]")
                validate_points([attribution[:2], attribution[2:]], 2, "attribution_box")
                if attribution[2] <= attribution[0] or attribution[3] <= attribution[1]:
                    raise ValueError("attribution_box must have positive width and height")
                camera_transform({}, 0, seconds, source_size, size, attribution)
            for keyframe in scene.get("camera", {}).values():
                if len(keyframe) != 3:
                    raise ValueError("camera keyframes must be [x, y, zoom]")
                validate_points([keyframe[:2]], 1, "camera")
                require_number(keyframe[2], 1, 20, "zoom")
            for group, count in (("regions", 3), ("routes", 2)):
                for overlay in scene.get(group, []):
                    if group == "regions" and "mask" in overlay:
                        if "points" in overlay:
                            raise ValueError("use either a region mask or polygon points")
                        with Image.open(root / overlay["mask"]) as mask:
                            if mask.size != source_size:
                                raise ValueError("region mask must match map pixel dimensions")
                            mask.verify()
                    else:
                        validate_points(overlay["points"], count, group)
                    start, end = overlay.get("reveal", (0, 0))
                    require_number(start, 0, seconds, f"{group} reveal start")
                    require_number(end, start, seconds, f"{group} reveal end")
                    for color_key in ("color", "outline", "glow"):
                        if color_key in overlay:
                            color = overlay[color_key]
                            if not (color.startswith("#") and len(color) == 7):
                                raise ValueError("use #RRGGBB overlay colors")
                            ImageColor.getrgb(color)
                    if group == "regions":
                        require_number(overlay.get("opacity", 0.45), 0, 1, "region opacity")
                    else:
                        require_number(overlay.get("icon_scale", 0.07), 0.005, 0.4, "icon_scale")
                        require_number(overlay.get("width", 0.010), 0.002, 0.04, "route width")
            for marker in scene.get("markers", []):
                validate_points([marker["at"]], 1, "marker")
                require_number(marker.get("show_from", 0), 0, seconds, "show_from")
            for entry in [*scene.get("routes", []), *scene.get("markers", [])]:
                if entry.get("icon"):
                    with Image.open(root / entry["icon"]) as icon:
                        icon.verify()
            previous_end = 0
            for cue in scene.get("cues", []):
                require_number(cue["start"], previous_end, seconds, "cue start")
                require_number(cue["end"], cue["start"], seconds, "cue end")
                if (cue["end"] <= cue["start"] or not cue["text"].strip()
                        or len(cue["text"].splitlines()) > 2):
                    raise ValueError("subtitle cues must have a positive duration and 1–2 lines")
                previous_end = cue["end"]
            frames.append(max(1, math.ceil(seconds * fps - 1e-9)))
        except (KeyError, OSError, TypeError, ValueError) as error:
            raise ValueError(f"scene {index}: {error}") from error
    return frames


def srt_time(seconds):
    total_ms = round(seconds * 1000)
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    whole_seconds, ms = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{whole_seconds:02d},{ms:03d}"


def write_srt(path, scenes, frames, fps):
    entries = []
    offset = 0
    for scene, count in zip(scenes, frames):
        for cue in scene.get("cues", []):
            start = srt_time(offset + cue["start"])
            end = srt_time(offset + cue["end"])
            entries.append(f"{len(entries)+1}\n{start} --> {end}\n{cue['text'].strip()}\n")
        offset += count / fps
    path.write_text("\n".join(entries), encoding="utf-8")


def render_video(ffmpeg, path, scenes, frames, args, size, log, audio_path):
    width, height = size
    command = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "rawvideo",
        "-pixel_format", "rgb24", "-video_size", f"{width}x{height}",
        "-framerate", str(args.fps), "-i", "pipe:0",
    ]
    if audio_path:
        clip_seconds = f"{sum(frames) / args.fps:.9f}"
        command.extend(["-i", str(audio_path), "-map", "0:v:0", "-map", "1:a:0",
                        "-af", "apad", "-t", clip_seconds, "-c:a", "aac", "-b:a", "160k"])
    command.extend(["-c:v", "libx264", "-preset", "fast", "-crf", "18",
                    "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(path)])
    with log.open("wb") as error_output, subprocess.Popen(
        command, stdin=subprocess.PIPE, stderr=error_output,
    ) as encoder:
        broken_pipe = None
        try:
            for scene, count in zip(scenes, frames):
                with Image.open(args.timeline.parent / scene["map"]) as source:
                    base = source.convert("RGB")
                camera_duration = max((count - 1) / args.fps, 1 / args.fps)
                for frame in range(count):
                    image = render_frame(base, scene, frame / args.fps,
                                         camera_duration, size, str(args.font), args.timeline.parent)
                    encoder.stdin.write(image.tobytes())
        except BrokenPipeError as error:
            broken_pipe = error
        finally:
            try:
                encoder.stdin.close()
            except BrokenPipeError as error:
                broken_pipe = error
        if encoder.wait() or broken_pipe:
            raise RuntimeError(log.read_text(encoding="utf-8").strip() or "FFmpeg encoding failed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("timeline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--font", type=Path, default=DEFAULT_FONT, help="Thai font (default: bundled Kanit Bold)")
    voice = parser.add_mutually_exclusive_group()
    voice.add_argument("--audio", type=Path, help="a single narration file already aligned to the timeline")
    voice.add_argument("--cue-audio", type=Path,
                       help="directory of WAV cues named by scene and cue, e.g. 01-01.wav")
    parser.add_argument("--size", default="1080x1920")
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--force", action="store_true", help="replace existing MP4 and SRT outputs")
    args = parser.parse_args()
    try:
        size = parse_size(args.size)
        require_number(args.fps, 1, 60, "fps")
        if args.output.suffix.lower() != ".mp4":
            raise ValueError("output filename must end in .mp4")
        srt = args.output.with_suffix(".srt")
        if not args.force and (args.output.exists() or srt.exists()):
            raise ValueError("output already exists. Choose a new filename or use --force.")
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg or not features.check("raqm"):
            raise RuntimeError("FFmpeg and Pillow with libraqm support are required")
        font_at(str(args.font), 24)
        if args.audio and not args.audio.is_file():
            raise ValueError(f"audio file not found: {args.audio}")
        scenes = json.loads(args.timeline.read_text(encoding="utf-8"))["scenes"]
        frames = validate_scenes(scenes, args.timeline.parent, size, args.fps)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with TemporaryDirectory(dir=args.output.parent) as temporary:
            folder = Path(temporary)
            mp4_temp, srt_temp = folder / "output.mp4", folder / "output.srt"
            audio_path = args.audio
            if args.cue_audio:
                audio_path = folder / "narration.wav"
                scenes, frames = align_cue_audio(ffmpeg, scenes, frames, args.cue_audio, audio_path, args.fps)
            write_srt(srt_temp, scenes, frames, args.fps)
            render_video(ffmpeg, mp4_temp, scenes, frames, args, size, folder / "ffmpeg.log", audio_path)
            os.replace(mp4_temp, args.output)
            os.replace(srt_temp, srt)
    except (AttributeError, KeyError, OSError, RuntimeError, TypeError, ValueError) as error:
        parser.exit(1, f"Error: {error}\n")
    print(f"Created {args.output} and {srt}")


if __name__ == "__main__":
    main()
