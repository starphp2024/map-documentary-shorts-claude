#!/usr/bin/env python3
"""Build an olive/navy shaded relief map from Mapzen Terrarium tiles."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import math
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import numpy as np
from PIL import Image

TILE_SIZE = 256
TILE_URL = "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"


def mercator(lon, lat, zoom):
    world = TILE_SIZE * (2 ** zoom)
    return ((lon + 180) * world / 360,
            (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) * world / 2)


def read_tile(cache, zoom, x, y):
    wrapped_x = x % (2 ** zoom)
    path = cache / f"{zoom}-{wrapped_x}-{y}.png"
    if path.is_file():
        return x, y, path.read_bytes()
    for attempt in range(3):
        try:
            with urlopen(TILE_URL.format(z=zoom, x=wrapped_x, y=y), timeout=18) as response:
                data = response.read()
            with Image.open(BytesIO(data)) as tile:
                if tile.size != (TILE_SIZE, TILE_SIZE):
                    raise ValueError("expected a 256×256 Terrarium tile")
                tile.verify()
            path.write_bytes(data)
            return x, y, data
        except (URLError, OSError) as error:
            if attempt == 2:
                raise RuntimeError(f"could not fetch Mapzen tile {zoom}/{wrapped_x}/{y}: {error}") from error


def stitch(cache, zoom, bounds, size):
    west, south, east, north = bounds
    x0, y0 = mercator(west, north, zoom)
    x1, y1 = mercator(east, south, zoom)
    target_ratio = size[0] / size[1]
    if (x1 - x0) / (y1 - y0) < target_ratio:
        margin = ((y1 - y0) * target_ratio - (x1 - x0)) / 2
        x0, x1 = x0 - margin, x1 + margin
    else:
        margin = ((x1 - x0) / target_ratio - (y1 - y0)) / 2
        y0, y1 = y0 - margin, y1 + margin
    xmin, xmax = math.floor(x0 / TILE_SIZE), math.ceil(x1 / TILE_SIZE)
    ymin, ymax = math.floor(y0 / TILE_SIZE), math.ceil(y1 / TILE_SIZE)
    count = (xmax - xmin) * (ymax - ymin)
    if count > 260:
        raise ValueError(f"area needs {count} tiles. Use a lower zoom or a smaller area.")
    if ymin < 0 or ymax > 2 ** zoom:
        raise ValueError("portrait framing goes past the supported Mercator latitude range")
    cache.mkdir(parents=True, exist_ok=True)
    data = np.empty(((ymax-ymin)*TILE_SIZE, (xmax-xmin)*TILE_SIZE), dtype=np.float32)
    with ThreadPoolExecutor(max_workers=12) as pool:
        jobs = [pool.submit(read_tile, cache, zoom, x, y)
                for y in range(ymin, ymax) for x in range(xmin, xmax)]
        for job in jobs:
            x, y, payload = job.result()
            with Image.open(BytesIO(payload)) as tile:
                rgb = np.asarray(tile.convert("RGB"), dtype=np.float32)
            elev = rgb[:, :, 0] * 256 + rgb[:, :, 1] + rgb[:, :, 2] / 256 - 32768
            left, top = (x - xmin) * TILE_SIZE, (y - ymin) * TILE_SIZE
            data[top:top+TILE_SIZE, left:left+TILE_SIZE] = elev
    crop = (x0-xmin*TILE_SIZE, y0-ymin*TILE_SIZE,
            x1-xmin*TILE_SIZE, y1-ymin*TILE_SIZE)
    dem = Image.fromarray(data).transform(size, Image.Transform.EXTENT, crop, Image.Resampling.BILINEAR)
    return np.asarray(dem), (x0, y0, x1, y1)


def shade(elevation):
    land = elevation > 0
    # Cap the color ramps so coastal lowlands stay olive and the seafloor stays navy.
    height = np.clip(elevation / 1800, 0, 1) ** 0.76
    shallow = np.exp(np.minimum(elevation, 0) / 950)
    land_color = np.array([62, 73, 36]) + height[:, :, None] * np.array([106, 82, 42])
    sea_color = np.array([9, 20, 39]) + shallow[:, :, None] * np.array([10, 29, 48])
    grad_y, grad_x = np.gradient(elevation)
    nx, ny = -grad_x * 0.026, -grad_y * 0.026
    light = (-0.52 * nx - 0.50 * ny + 0.69) / np.sqrt(1 + nx * nx + ny * ny)
    land_color *= np.clip(0.62 + 0.72 * light, 0.42, 1.37)[:, :, None]
    sea_color *= np.clip(0.96 + (light - 0.69) * 0.18, 0.8, 1.08)[:, :, None]
    rgb = np.where(land[:, :, None], land_color, sea_color)
    return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--bounds", nargs=4, type=float, metavar=("WEST", "SOUTH", "EAST", "NORTH"),
                        required=True, help="longitude and latitude limits in degrees")
    parser.add_argument("--zoom", default=8, type=int)
    parser.add_argument("--size", default="1080x1920")
    parser.add_argument("--cache", type=Path, default=Path(".terrain-cache"))
    args = parser.parse_args()
    west, south, east, north = args.bounds
    if not (-180 <= west < east <= 180 and -85 < south < north < 85 and 0 <= args.zoom <= 13):
        parser.error("use ordered geographic limits and a tile zoom from 0 to 13")
    try:
        size = tuple(map(int, args.size.lower().split("x")))
        if len(size) != 2 or not (128 <= size[0] < size[1] <= 3840):
            raise ValueError("use portrait dimensions such as 1080x1920")
        dem, extent = stitch(args.cache, args.zoom, args.bounds, size)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        shade(dem).save(args.output)
        print(f"Created {args.output}. EPSG:3857 global pixels at z{args.zoom}: {extent}")
        print("Terrain: Mapzen Terrain Tiles (SRTM, GMTED, ETOPO1).")
    except (OSError, RuntimeError, ValueError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
